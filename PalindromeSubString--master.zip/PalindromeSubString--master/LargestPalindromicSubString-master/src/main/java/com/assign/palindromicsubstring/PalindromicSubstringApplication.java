package com.assign.palindromicsubstring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PalindromicSubstringApplication {

	public static void main(String[] args) {
		SpringApplication.run(PalindromicSubstringApplication.class, args);
	}

}
