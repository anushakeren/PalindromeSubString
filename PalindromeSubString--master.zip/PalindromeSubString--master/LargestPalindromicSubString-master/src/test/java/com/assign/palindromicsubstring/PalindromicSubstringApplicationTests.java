package com.assign.palindromicsubstring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PalindromicSubstringApplicationTests {

	@Test
	void contextLoads() {
	}

}
