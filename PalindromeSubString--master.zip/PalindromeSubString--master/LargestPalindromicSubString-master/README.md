# LargestPalindromicSubString
For given string api saves largest palindromic substring 

API can be accessed by below URL's : <br/>
1 . http://localhost:8080/palindrome/find/palindrome (POST request) , give the body with string to be saved <br/>
2 . http://localhost:8080/palindrome/get/largest/palindrome (GET request) , returns the largest palindromic string stored in IN MEMORY DB <br/>
3 . http://localhost:8080/palindrome//getBinaryMapping (POST request) , give the body with string to be saved 

